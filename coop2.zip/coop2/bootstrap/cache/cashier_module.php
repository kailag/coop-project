<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cashier\\Providers\\CashierServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cashier\\Providers\\CashierServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);