<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bookeeping\\Providers\\BookeepingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bookeeping\\Providers\\BookeepingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);