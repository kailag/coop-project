<?php

return [
    'name' => 'Employee'
];
