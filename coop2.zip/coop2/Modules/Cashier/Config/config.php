<?php

return [
    'name' => 'Cashier'
];
