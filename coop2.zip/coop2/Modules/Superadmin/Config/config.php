<?php

return [
    'name' => 'Superadmin'
];
